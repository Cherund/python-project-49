from brain_games.games.gcd import gcd


def main():
    gcd()


if __name__ == '__main__':
    main()
