### Hexlet tests and linter status:
[![Actions Status](https://github.com/Cherund/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Cherund/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/df95b9c570df11ee5a2e/maintainability)](https://codeclimate.com/github/Cherund/python-project-49/maintainability)

### Asciinema
##### Installing package and demonstrating brain-even
https://asciinema.org/a/UKhbQmgX2UBFfZr0QuDlE4Vw7
##### Demonstrating brain-calc
https://asciinema.org/a/WHaIqQ8i5jymJWg5pKGPtvwxp
##### Demonstrating brain gcd
https://asciinema.org/a/bNwerhRahaxahr6X3VlcfDRXw
##### Demonstrating brain progression
https://asciinema.org/a/IwH1pNCKLfLZOFRvgUdWwvI6M
##### Demonstrating brain prime
https://asciinema.org/a/TWwQzAnp5lks7tFru1LoHYjsg