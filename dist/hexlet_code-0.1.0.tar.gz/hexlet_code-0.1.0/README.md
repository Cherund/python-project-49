### Hexlet tests and linter status:
[![Actions Status](https://github.com/Cherund/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Cherund/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/df95b9c570df11ee5a2e/maintainability)](https://codeclimate.com/github/Cherund/python-project-49/maintainability)
